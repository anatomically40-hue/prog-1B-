package wildliferescue;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * RescueCalculationsTest verifies the cost and priority calculations for
 * each of the three rescue types, using the assumptions documented in
 * InjuredAnimalRescue, OrphanedAnimalRescue and EndangeredSpeciesRescue.
 */
public class RescueCalculationsTest {

    private static final double DELTA = 0.001; // acceptable rounding error for double comparisons

    // ---------- Injured Animal Rescue: cost calculation ----------

    @Test
    public void testInjuredAnimalRescueCost_withSurgery() {
        // base cost = 5 days x R1000 = R5000
        // + vet cost R15000
        // + surgery surcharge R5000
        // expected total = R25000
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR001", "Elephant", "African Elephant", "Kruger", "Ranger A",
                5, 1000.00, "Broken leg", 15000.00, true);

        assertEquals(25000.00, rescue.calculateTotalCost(), DELTA);
    }

    @Test
    public void testInjuredAnimalRescueCost_withoutSurgery() {
        // base cost = 5 days x R1000 = R5000
        // + vet cost R2000
        // no surgery surcharge
        // expected total = R7000
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR002", "Buck", "Kudu", "Kruger", "Ranger A",
                5, 1000.00, "Minor cut", 2000.00, false);

        assertEquals(7000.00, rescue.calculateTotalCost(), DELTA);
    }

    // ---------- Injured Animal Rescue: priority calculation ----------

    @Test
    public void testInjuredAnimalRescuePriority_surgeryIsCritical() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR003", "Lion", "African Lion", "Kruger", "Ranger A",
                4, 1000.00, "Severe wound", 4000.00, true);

        assertEquals(RescuePriority.CRITICAL, rescue.determineRescuePriority());
    }

    @Test
    public void testInjuredAnimalRescuePriority_highVetCostWithoutSurgeryIsHigh() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR004", "Lion", "African Lion", "Kruger", "Ranger A",
                4, 1000.00, "Deep wound", 3500.00, false);

        assertEquals(RescuePriority.HIGH, rescue.determineRescuePriority());
    }

    @Test
    public void testInjuredAnimalRescuePriority_lowVetCostIsMedium() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR005", "Buck", "Kudu", "Kruger", "Ranger A",
                4, 1000.00, "Minor cut", 500.00, false);

        assertEquals(RescuePriority.MEDIUM, rescue.determineRescuePriority());
    }

    // ---------- Orphaned Animal Rescue: cost calculation ----------

    @Test
    public void testOrphanedAnimalRescueCost_withFosterCare() {
        // base cost = 10 days x R800 = R8000
        // + feeding cost R3000
        // + foster care surcharge R2500
        // expected total = R13500
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR006", "Rhino Calf", "White Rhino", "Hluhluwe", "Ranger B",
                10, 800.00, 6, 3000.00, true);

        assertEquals(13500.00, rescue.calculateTotalCost(), DELTA);
    }

    @Test
    public void testOrphanedAnimalRescueCost_withoutFosterCare() {
        // base cost = 10 days x R800 = R8000
        // + feeding cost R1500
        // no foster care surcharge
        // expected total = R9500
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR007", "Rhino Calf", "White Rhino", "Hluhluwe", "Ranger B",
                10, 800.00, 6, 1500.00, false);

        assertEquals(9500.00, rescue.calculateTotalCost(), DELTA);
    }

    // ---------- Orphaned Animal Rescue: priority calculation ----------

    @Test
    public void testOrphanedAnimalRescuePriority_veryYoungIsHigh() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR008", "Rhino Calf", "White Rhino", "Hluhluwe", "Ranger B",
                10, 800.00, 2, 3000.00, true);

        assertEquals(RescuePriority.HIGH, rescue.determineRescuePriority());
    }

    @Test
    public void testOrphanedAnimalRescuePriority_olderWithFosterCareIsMedium() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR009", "Rhino Calf", "White Rhino", "Hluhluwe", "Ranger B",
                10, 800.00, 8, 3000.00, true);

        assertEquals(RescuePriority.MEDIUM, rescue.determineRescuePriority());
    }

    @Test
    public void testOrphanedAnimalRescuePriority_olderWithoutFosterCareIsLow() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR010", "Rhino Calf", "White Rhino", "Hluhluwe", "Ranger B",
                10, 800.00, 8, 1500.00, false);

        assertEquals(RescuePriority.LOW, rescue.determineRescuePriority());
    }

    // ---------- Endangered Species Rescue: cost calculation ----------

    @Test
    public void testEndangeredSpeciesRescueCost_withSpecialistTeam() {
        // base cost = 7 days x R1200 = R8400
        // + security cost R6000
        // + specialist team surcharge R8000
        // expected total = R22400
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR011", "Pangolin", "Pangolin", "Limpopo", "Ranger C",
                7, 1200.00, "Critically Endangered", 6000.00, true);

        assertEquals(22400.00, rescue.calculateTotalCost(), DELTA);
    }

    @Test
    public void testEndangeredSpeciesRescueCost_withoutSpecialistTeam() {
        // base cost = 7 days x R1200 = R8400
        // + security cost R2000
        // no specialist team surcharge
        // expected total = R10400
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR012", "Pangolin", "Pangolin", "Limpopo", "Ranger C",
                7, 1200.00, "Critically Endangered", 2000.00, false);

        assertEquals(10400.00, rescue.calculateTotalCost(), DELTA);
    }

    // ---------- Endangered Species Rescue: priority calculation ----------

    @Test
    public void testEndangeredSpeciesRescuePriority_specialistTeamIsCritical() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR013", "Pangolin", "Pangolin", "Limpopo", "Ranger C",
                7, 1200.00, "Critically Endangered", 6000.00, true);

        assertEquals(RescuePriority.CRITICAL, rescue.determineRescuePriority());
    }

    @Test
    public void testEndangeredSpeciesRescuePriority_noSpecialistTeamIsHigh() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR014", "Pangolin", "Pangolin", "Limpopo", "Ranger C",
                7, 1200.00, "Vulnerable", 2000.00, false);

        assertEquals(RescuePriority.HIGH, rescue.determineRescuePriority());
    }

    // ---------- Rescue status updates (via RescueOperations interface) ----------

    @Test
    public void testStartRescue_updatesStatusToInProgress() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR015", "Elephant", "African Elephant", "Kruger", "Ranger A",
                5, 1000.00, "Broken leg", 15000.00, true);

        assertEquals(RescueStatus.PENDING, rescue.getCurrentStatus());
        rescue.startRescue();
        assertEquals(RescueStatus.RESCUE_IN_PROGRESS, rescue.getCurrentStatus());
    }

    @Test
    public void testCompleteRescue_updatesStatusToCompleted() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR016", "Elephant", "African Elephant", "Kruger", "Ranger A",
                5, 1000.00, "Broken leg", 15000.00, true);

        rescue.startRescue();
        rescue.completeRescue();
        assertEquals(RescueStatus.COMPLETED, rescue.getCurrentStatus());
    }
}
