/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.wildliferescue;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
/**
 *
 * @author anato
 */
//Rescuable
 
interface Rescuable {
    void startRescue();
    void completeRescue();
    String generateSummary();
}
 
//RescueStatus
 
enum RescueStatus {
    REPORTED("Reported"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed");
 
    private final String label;
 
    RescueStatus(String label) {
        this.label = label;
    }
 
    @Override
    public String toString() {
        return label;
    }
}
 
//RescuePriority
 
enum RescuePriority {
    LOW, MEDIUM, HIGH, CRITICAL
}
 
// abstract base class
 
abstract class RescueCase implements Rescuable {
 
    private String rescueId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private RescueStatus status;
 
    public RescueCase(String rescueId, String animalName, String species,
                       String rescueLocation, String assignedRanger,
                       int numberOfRescueDays, double dailyCareCost) {
        this.rescueId = rescueId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = RescueStatus.REPORTED;
    }
 
    //Getters and setters
 
    public String getRescueId() {
        return rescueId;
    }
 
    public String getAnimalName() {
        return animalName;
    }
 
    public String getSpecies() {
        return species;
    }
 
    public String getRescueLocation() {
        return rescueLocation;
    }
 
    public String getAssignedRanger() {
        return assignedRanger;
    }
 
    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }
 
    public double getDailyCareCost() {
        return dailyCareCost;
    }
 
    public RescueStatus getStatus() {
        return status;
    }
 
    public void setStatus(RescueStatus status) {
        this.status = status;
    }
 
    //Shared calculation helper
 
    protected double calculateBaseCost() {
        return numberOfRescueDays * dailyCareCost;
    }
 
    //Abstract methods every rescue type must implement
 
    public abstract double calculateTotalCost();
 
    public abstract RescuePriority determineRescuePriority();
 
    public abstract String displaySpecialisedInformation();
 
    public abstract String getRescueType();
 
    // ---- Rescuable interface implementation shared by all subclasses
 
    @Override
    public void startRescue() {
        this.status = RescueStatus.IN_PROGRESS;
    }
 
    @Override
    public void completeRescue() {
        this.status = RescueStatus.COMPLETED;
    }
 
    @Override
    public String generateSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("--------------------------------------------\n");
        summary.append("RESCUE SUMMARY\n");
        summary.append("--------------------------------------------\n");
        summary.append(String.format("Rescue Case ID   : %s%n", rescueId));
        summary.append(String.format("Rescue Type      : %s%n", getRescueType()));
        summary.append(String.format("Species          : %s%n", species));
        summary.append(String.format("Assigned Ranger  : %s%n", assignedRanger));
        summary.append(String.format("Rescue Priority  : %s%n", determineRescuePriority()));
        summary.append(String.format("Current Status   : %s%n", status));
        summary.append(String.format("Total Rescue Cost: %s%n", CurrencyFormatter.formatRand(calculateTotalCost())));
        summary.append("--------------------------------------------");
        return summary.toString();
    }
 
    // METHOD OVERRIDING: gives every rescue case a meaningful text form for reports.
    @Override
    public String toString() {
        return String.format(
            "Case ID       : %s%n" +
            "Type          : %s%n" +
            "Species       : %s%n" +
            "Location      : %s%n" +
            "Ranger        : %s%n" +
            "Priority      : %s%n" +
            "Status        : %s%n" +
            "Total Cost    : %s",
            rescueId, getRescueType(), species, rescueLocation,
            assignedRanger, determineRescuePriority(), status,
            CurrencyFormatter.formatRand(calculateTotalCost())
        );
    }
}
 
// InjuredAnimalRescue
 
class InjuredAnimalRescue extends RescueCase {
 
    private static final double SURGERY_SURCHARGE = 5000.00;
 
    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;
 
    public InjuredAnimalRescue(String rescueId, String animalName, String species,
                                String rescueLocation, String assignedRanger,
                                int numberOfRescueDays, double dailyCareCost,
                                String injuryDescription, double veterinaryTreatmentCost,
                                boolean surgeryRequired) {
        super(rescueId, animalName, species, rescueLocation, assignedRanger,
              numberOfRescueDays, dailyCareCost);
        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }
 
    // Total cost = base cost + vet cost (+ R5000 if surgery required)
    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + veterinaryTreatmentCost;
        if (surgeryRequired) {
            total += SURGERY_SURCHARGE;
        }
        return total;
    }
 
    @Override
    public RescuePriority determineRescuePriority() {
        if (surgeryRequired) {
            return RescuePriority.CRITICAL;
        } else if (veterinaryTreatmentCost > 3000.00) {
            return RescuePriority.HIGH;
        } else {
            return RescuePriority.MEDIUM;
        }
    }
 
    @Override
    public String displaySpecialisedInformation() {
        return String.format(
            "Injury Description       : %s%n" +
            "Veterinary Treatment Cost : %s%n" +
            "Surgery Required          : %s",
            injuryDescription,
            CurrencyFormatter.formatRand(veterinaryTreatmentCost),
            surgeryRequired ? "Yes" : "No"
        );
    }
 
    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }
}
 
//OrphanedAnimalRescue 
 
class OrphanedAnimalRescue extends RescueCase {
 
    private static final double FOSTER_CARE_SURCHARGE = 2500.00;
 
    private int estimatedAgeInMonths;
    private double feedingCost;
    private boolean fosterCareRequired;
 
    public OrphanedAnimalRescue(String rescueId, String animalName, String species,
                                 String rescueLocation, String assignedRanger,
                                 int numberOfRescueDays, double dailyCareCost,
                                 int estimatedAgeInMonths, double feedingCost,
                                 boolean fosterCareRequired) {
        super(rescueId, animalName, species, rescueLocation, assignedRanger,
              numberOfRescueDays, dailyCareCost);
        this.estimatedAgeInMonths = estimatedAgeInMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }
 
    // Total cost = base cost + feeding cost (+ R2500 if foster care required)
    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + feedingCost;
        if (fosterCareRequired) {
            total += FOSTER_CARE_SURCHARGE;
        }
        return total;
    }
 
    @Override
    public RescuePriority determineRescuePriority() {
        if (estimatedAgeInMonths <= 3) {
            return RescuePriority.HIGH;
        } else if (fosterCareRequired) {
            return RescuePriority.MEDIUM;
        } else {
            return RescuePriority.LOW;
        }
    }
 
    @Override
    public String displaySpecialisedInformation() {
        return String.format(
            "Estimated Age (Months) : %d%n" +
            "Feeding Cost            : %s%n" +
            "Foster Care Required    : %s",
            estimatedAgeInMonths,
            CurrencyFormatter.formatRand(feedingCost),
            fosterCareRequired ? "Yes" : "No"
        );
    }
 
    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }
}
 
//EndangeredSpeciesRescue
 
class EndangeredSpeciesRescue extends RescueCase {
 
    private static final double SPECIALIST_TEAM_SURCHARGE = 8000.00;
 
    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;
 
    public EndangeredSpeciesRescue(String rescueId, String animalName, String species,
                                    String rescueLocation, String assignedRanger,
                                    int numberOfRescueDays, double dailyCareCost,
                                    String conservationClassification, double securityCost,
                                    boolean specialistTeamRequired) {
        super(rescueId, animalName, species, rescueLocation, assignedRanger,
              numberOfRescueDays, dailyCareCost);
        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }
 
    // Total cost = base cost + security cost (+ R8000 if the specialist team required)
    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + securityCost;
        if (specialistTeamRequired) {
            total += SPECIALIST_TEAM_SURCHARGE;
        }
        return total;
    }
 
     @Override
    public RescuePriority determineRescuePriority() {
        if (specialistTeamRequired) {
            return RescuePriority.CRITICAL;
        } else {
            return RescuePriority.HIGH;
        }
    }
 
    @Override
    public String displaySpecialisedInformation() {
        return String.format(
            "Conservation Classification : %s%n" +
            "Security Cost                : %s%n" +
            "Specialist Team Required      : %s",
            conservationClassification,
            CurrencyFormatter.formatRand(securityCost),
            specialistTeamRequired ? "Yes" : "No"
        );
    }
 
    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }
}
 
//CurrencyFormatter
 
/** Formats amounts as South African Rand, e.g. 20500.0 -> "R20 500.00". */
class CurrencyFormatter {
 
    public static String formatRand(double amount) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        symbols.setGroupingSeparator(' ');
        DecimalFormat formatter = new DecimalFormat("#,##0.00", symbols);
        return "R" + formatter.format(amount);
    }
}
 
//RescueManager
 

class RescueManager {
 
    private ArrayList<RescueCase> rescues;
 
    public RescueManager() {
        rescues = new ArrayList<>();
    }
 
    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
 
    public boolean isCaseIdUnique(String rescueId) {
        for (RescueCase rescue : rescues) {
            if (rescue.getRescueId().equalsIgnoreCase(rescueId)) {
                return false;
            }
        }
        return true;
    }
 
     public void addRescue(RescueCase newRescue) {
        if (isBlank(newRescue.getRescueId())) {
            throw new IllegalArgumentException("Rescue Case ID cannot be blank.");
        }
        if (!isCaseIdUnique(newRescue.getRescueId())) {
            throw new IllegalArgumentException(
                "Rescue Case ID '" + newRescue.getRescueId() + "' already exists. IDs must be unique.");
        }
        if (isBlank(newRescue.getSpecies())) {
            throw new IllegalArgumentException("Species cannot be blank.");
        }
        if (isBlank(newRescue.getRescueLocation())) {
            throw new IllegalArgumentException("Rescue Location cannot be blank.");
        }
        if (isBlank(newRescue.getAssignedRanger())) {
            throw new IllegalArgumentException("Assigned Ranger cannot be blank.");
        }
        rescues.add(newRescue);
    }
 
    public RescueCase findRescue(String rescueId) {
        for (RescueCase rescue : rescues) {
            if (rescue.getRescueId().equalsIgnoreCase(rescueId)) {
                return rescue;
            }
        }
        return null;
    }
 
    public boolean updateStatus(String rescueId, RescueStatus newStatus) {
        RescueCase rescue = findRescue(rescueId);
        if (rescue == null) {
            return false;
        }
        rescue.setStatus(newStatus);
        return true;
    }
 
    public ArrayList<RescueCase> getAllRescues() {
        return rescues;
    }
 
    public int getTotalNumberOfCases() {
        return rescues.size();
    }
 
    public double getTotalEstimatedCost() {
        double total = 0.0;
        for (RescueCase rescue : rescues) {
            total += rescue.calculateTotalCost();
        }
        return total;
    }
 
    public String generateReport() {
        StringBuilder report = new StringBuilder();
        report.append("============================================\n");
        report.append("WILDLIFE RESCUE REPORT\n");
        report.append("============================================\n\n");
 
        if (rescues.isEmpty()) {
            report.append("No rescue cases have been recorded yet.\n");
        } else {
            for (RescueCase rescue : rescues) {
                report.append(rescue.toString()).append("\n");
                report.append("--------------------------------------------\n\n");
            }
        }
 
        report.append(String.format("Total Rescue Cases : %d%n", getTotalNumberOfCases()));
        report.append(String.format("Total Rescue Cost  : %s%n", CurrencyFormatter.formatRand(getTotalEstimatedCost())));
 
        return report.toString();
    }
}
public class Wildliferescue {

    private static final Scanner in = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();
 
    public static void main(String[] args) {
        boolean running = true;
 
        while (running) {
            printMenu();
            int choice = readMenuChoice(1, 9);
 
            switch (choice) {
                case 1: createRescue(); break;
                case 2: searchRescue(); break;
                case 3: updateStatus(); break;
                case 4: displayAllRescues(); break;
                case 5: startRescue(); break;
                case 6: completeRescue(); break;
                case 7: generateSummary(); break;
                case 8: System.out.println(manager.generateReport()); break;
                case 9:
                    running = false;
                    System.out.println("Thank you for using the Wildlife Rescue Operations System. Goodbye!");
                    break;
            }
        }
 
        in.close();
    }
 
    private static void printMenu() {
        System.out.println();
        System.out.println("===================================");
        System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("===================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Start Rescue Operation");
        System.out.println("6. Complete Rescue Operation");
        System.out.println("7. Generate Rescue Summary");
        System.out.println("8. Rescue Report");
        System.out.println("9. Exit");
        System.out.print("Select an option: ");
    }
 
    //Create  a Rescue file
 
    private static void createRescue() {
        System.out.println();
        System.out.println("---- Create New Rescue Case ----");
 
        String rescueId = readNonBlankString("Enter Rescue Case ID: ");
        String animalName = readNonBlankString("Enter Animal Name: ");
        String species = readNonBlankString("Enter Species: ");
        String rescueLocation = readNonBlankString("Enter Rescue Location: ");
        String assignedRanger = readNonBlankString("Enter Assigned Ranger: ");
        int numberOfRescueDays = readPositiveInt("Enter Number of Rescue Days: ");
        double dailyCareCost = readPositiveDouble("Enter Daily Care Cost (R): ");
 
        System.out.println("Select Rescue Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");
        int typeChoice = readMenuChoice(1, 3);
 
        RescueCase newRescue = null;
 
        if (typeChoice == 1) {
            String injuryDescription = readNonBlankString("Enter Injury Description: ");
            double vetCost = readPositiveDouble("Enter Veterinary Treatment Cost (R): ");
            boolean surgeryRequired = readYesNo("Is Surgery Required? (Y/N): ");
            newRescue = new InjuredAnimalRescue(rescueId, animalName, species,
                    rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost,
                    injuryDescription, vetCost, surgeryRequired);
        } else if (typeChoice == 2) {
            int ageInMonths = readPositiveInt("Enter Estimated Age (Months): ");
            double feedingCost = readPositiveDouble("Enter Feeding Cost (R): ");
            boolean fosterCareRequired = readYesNo("Is Foster Care Required? (Y/N): ");
            newRescue = new OrphanedAnimalRescue(rescueId, animalName, species,
                    rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost,
                    ageInMonths, feedingCost, fosterCareRequired);
        } else if (typeChoice == 3) {
            String classification = readNonBlankString("Enter Conservation Classification: ");
            double securityCost = readPositiveDouble("Enter Security Cost (R): ");
            boolean specialistTeamRequired = readYesNo("Is a Specialist Team Required? (Y/N): ");
            newRescue = new EndangeredSpeciesRescue(rescueId, animalName, species,
                    rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost,
                    classification, securityCost, specialistTeamRequired);
        }
 
        try {
            manager.addRescue(newRescue);
            System.out.println("Rescue case '" + rescueId + "' created successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Could not create rescue case: " + e.getMessage());
        }
    }
 
    // Menu option 2: Search Rescue Case
 
    private static void searchRescue() {
        System.out.println();
        String rescueId = readNonBlankString("Enter Rescue Case ID to search for: ");
        RescueCase found = manager.findRescue(rescueId);
 
        if (found == null) {
            System.out.println("No rescue case found with ID '" + rescueId + "'.");
        } else {
            System.out.println();
            System.out.println(found.toString());
            System.out.println();
            System.out.println(found.displaySpecialisedInformation());
        }
    }
 
    //Update Rescue Status
 
    private static void updateStatus() {
        System.out.println();
        String rescueId = readNonBlankString("Enter Rescue Case ID to update: ");
        RescueCase found = manager.findRescue(rescueId);
 
        if (found == null) {
            System.out.println("No rescue case found with ID '" + rescueId + "'.");
            return;
        }
 
        System.out.println("Current Status: " + found.getStatus());
        System.out.println("Select New Status:");
        RescueStatus[] statuses = RescueStatus.values();
        for (int i = 0; i < statuses.length; i++) {
            System.out.println((i + 1) + ". " + statuses[i]);
        }
        int choice = readMenuChoice(1, statuses.length);
        RescueStatus newStatus = statuses[choice - 1];
 
        manager.updateStatus(rescueId, newStatus);
        System.out.println("Status updated to: " + newStatus);
    }
 
    //Display All Rescue Cases
 
    private static void displayAllRescues() {
        System.out.println();
        if (manager.getTotalNumberOfCases() == 0) {
            System.out.println("No rescue cases have been recorded yet.");
            return;
        }
 
        for (RescueCase rescue : manager.getAllRescues()) {
            System.out.println(rescue.toString());
            System.out.println("--------------------------------------------");
        }
    }
 
    //Start Rescue Operation
 
    private static void startRescue() {
        System.out.println();
        String rescueId = readNonBlankString("Enter Rescue Case ID to start: ");
        RescueCase found = manager.findRescue(rescueId);
 
        if (found == null) {
            System.out.println("No rescue case found with ID '" + rescueId + "'.");
            return;
        }
 
        found.startRescue();
        System.out.println("Rescue started. Status is now: " + found.getStatus());
    }
 
    //Complete Rescue Operation
 
    private static void completeRescue() {
        System.out.println();
        String rescueId = readNonBlankString("Enter Rescue Case ID to complete: ");
        RescueCase found = manager.findRescue(rescueId);
 
        if (found == null) {
            System.out.println("No rescue case found with ID '" + rescueId + "'.");
            return;
        }
 
        found.completeRescue();
        System.out.println("Rescue completed. Status is now: " + found.getStatus());
    }
 
    // generating a rescue summary
 
    private static void generateSummary() {
        System.out.println();
        String rescueId = readNonBlankString("Enter Rescue Case ID: ");
        RescueCase found = manager.findRescue(rescueId);
 
        if (found == null) {
            System.out.println("No rescue case found with ID '" + rescueId + "'.");
            return;
        }
 
        System.out.println();
        System.out.println(found.generateSummary());
    }
 
    // invalid inputS never crashes the program
 
    private static String readNonBlankString(String prompt) {
        String value;
        while (true) {
            System.out.print(prompt);
            value = in.nextLine();
            if (!RescueManager.isBlank(value)) {
                return value.trim();
            }
            System.out.println("This field cannot be blank. Please try again.");
        }
    }
 
    private static int readPositiveInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = in.nextLine();
            try {
                int value = Integer.parseInt(input.trim());
                if (value > 0) {
                    return value;
                }
                System.out.println("Please enter a number greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("That is not a valid whole number. Please try again.");
            }
        }
    }
 
    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = in.nextLine();
            try {
                double value = Double.parseDouble(input.trim());
                if (value > 0) {
                    return value;
                }
                System.out.println("Please enter an amount greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("That is not a valid amount. Please try again.");
            }
        }
    }
 
    private static boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = in.nextLine().trim().toLowerCase();
            if (input.equals("y") || input.equals("yes")) {
                return true;
            }
            if (input.equals("n") || input.equals("no")) {
                return false;
            }
            System.out.println("Please enter Y or N.");
        }
    }
 
    private static int readMenuChoice(int min, int max) {
        while (true) {
            String input = in.nextLine();
            try {
                int choice = Integer.parseInt(input.trim());
                if (choice >= min && choice <= max) {
                    return choice;
                }
                System.out.print("Please enter a number between " + min + " and " + max + ": ");
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Please enter a number between " + min + " and " + max + ": ");
            }
        }
    }
}
        
    
